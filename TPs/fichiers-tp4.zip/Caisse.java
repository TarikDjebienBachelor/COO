  


/**
 * la classe des caisses
 *  Dans cette version simple elles sont de diff�rents poids, mais on ne distingue
 *  pas les instances autrement
 * 
 * @author jc 
 * @version octobre 2005
 */

public class Caisse {   

    /** COMPLETER
     */
    public Caisse(int poids) {
        this.poids = poids;
    }
    
    // les attributs de la classe Caisse
    /** le poids de la caisse */
    private int poids;
    
    // les methodes de la classe Caisse 
    /** COMPLETER
     */
    public int donnePoids() {
        return this.poids;
    }
    
    // FAIRE JAVADOC
    public String toString() {
        return "caisse de poids "+this.poids;
    }
}
