import java.util.*; //pour pouvoir utiliser les classes du paquetage java.util
                    // par exemple ArrayList et Iterator

/**
 * la classe des TapisRoulant sur lesquels pn peut poser les caisses jusqu'un certain poids
 * les tapis ont une (m�me) capacit� maximale d�finie par <t>tailleMax</t>
 * @author jc 
 * @version septembre 2001
 */
public class TapisRoulant {

    /** le nombre maximal de caisse sur le tapid */
    static final private int capacite = 2;

    /**
     * constructeurs d'objets de la classe TapisRoulant
     */
    public TapisRoulant(int poidsMax) {
        this.poidsMax = poidsMax;
    }
    
    // les attributs de la classe TapisRoulant
    /** le poids maximum des caisses support�es */
    private int poidsMax;
    /** le tapis proprement dit : les caisses port�es */
    private ArrayList tapis = new ArrayList();
    
    // les methodes de la classe TapisRoulant
    /** donne le poids maximal accept�
     * @return le pods maximal accept�
     */
    public int donnePoidsMax() { return this.poidsMax; }
    
    /** la tapis re�oit une caisse 
     * @param caisse la caisse recue
     */
    public void recoit(Caisse caisse) {
        if (!this.estPlein()) {
            this.tapis.add(caisse);
        }
        else {          // pas de gestion d'exception pour l'instant
            System.out.println("tapis plein, impossible de deposer");
        }
    }
    /** indique si le tapis est plein
     * @return <t>true</t> si le tapis est plein de caisses
     */
    public boolean estPlein() {
        return this.tapis.size() == capacite;
    }
    /** v�rifie si le tapis peut accepter la caisse, ie. si elle n'est pas trop lourde
     * @param caisse : la caisse � v�rifier
     */
    public boolean accepte(Caisse caisse) {
        return caisse.donnePoids() <= this.poidsMax;
    }
    /** affiche le contenu du tapis roulant
     */
    public void affiche() {
        System.out.println("le tapis porte "+this.tapis.size()+" caisse(s)");
        // un <iterator> serait mieux mais pour avoir un exemple de boucle for 
        // cf. vide()
        for (int index=0; index < this.tapis.size(); index++) {
            System.out.println(this.tapis.get(index).toString());
        }                   
    }
    /** vide le tapis
     */
    public void videTapis() {
        Iterator lesCaisses_it = this.tapis.iterator();
        while(lesCaisses_it.hasNext()) {
            lesCaisses_it.next();
            lesCaisses_it.remove();
        }
    }
}
