package generics;

public interface Fruit {}
