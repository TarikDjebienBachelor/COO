package colis;

public class ColisAssurance extends Colis {

	private static final float COEFF = 2;

	public ColisAssurance() {
		super();
	}

	public float getFraisExpedition() {
		return COEFF*super.getFraisExpedition();
	}

}
