package colis;

public class ColisExpress extends Colis {

	private static final float LIMITE = 10;
	private static final float COUT_BAS = 5;
	private static final float COUT_HAUT = 10;

	public ColisExpress() {
		super();
	}

	public float getFraisExpedition() {
		float fraisBase = super.getFraisExpedition();
		if (fraisBase < LIMITE) {
			return COUT_BAS;
		} else {
			return COUT_HAUT;
		}
	}

}
