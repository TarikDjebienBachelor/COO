package colis;

import java.util.ArrayList;
import java.util.List;

import article.AbstractArticle;

public class Colis {
	protected List<AbstractArticle> lesArticles;
	private boolean estExpedie;
	
	public Colis() {
		this.lesArticles = new ArrayList<AbstractArticle>();
		this.estExpedie = false;
	}
	
	public float getFraisExpedition() {
		float somme = 0;
		for(AbstractArticle article : this.lesArticles) {
			somme = somme + article.fraisExpedition();
		}
		return somme;
	}
	
	public void expedie() {
		this.estExpedie = true;
	}
	
	public void addArticle(AbstractArticle article) throws ColisExpedieException {
		if (this.estExpedie) {
			throw new ColisExpedieException();
		}
		this.lesArticles.add(article);
	}
	
	public void afficheArticles() {
		for(AbstractArticle article : this.lesArticles) {
			System.out.println(article);
		}
	}
	
	public float getPrixTTC() {
		float prixTotal = 0;
		for(AbstractArticle article : this.lesArticles) {
			prixTotal = prixTotal + article.getPrixTTC();
		}
		return prixTotal;
	}
	
	// sans doute prevoir methode removeArticle(...) mais hors-sujet
}
