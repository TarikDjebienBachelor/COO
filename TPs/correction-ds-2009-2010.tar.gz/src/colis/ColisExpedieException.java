package colis;

public class ColisExpedieException extends Exception {

	public ColisExpedieException() {
		super("colis deja expedie");
	}

}
