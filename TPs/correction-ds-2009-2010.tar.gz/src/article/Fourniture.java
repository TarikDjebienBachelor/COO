package article;

public class Fourniture extends Electronique {

	private static final float FRAIS_EXPEDITION = 0;

	public Fourniture(float prixHt, String nom, int poids, int garantie) {
		super(prixHt, nom, poids, garantie);		
	}

	@Override
	public float fraisExpedition() {		
		return FRAIS_EXPEDITION;
	}

}
