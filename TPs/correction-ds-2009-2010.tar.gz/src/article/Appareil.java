package article;

public class Appareil extends Electronique {

	private static final float POURCENTAGE = 10;
	private static final int FIXE = 2;

	public Appareil(float prixHt, String nom, int poids, int garantie) {
		super(prixHt, nom, poids, garantie);
	}

	public float fraisExpedition() {
		return FIXE+(this.poids*POURCENTAGE/100);
	}

}
