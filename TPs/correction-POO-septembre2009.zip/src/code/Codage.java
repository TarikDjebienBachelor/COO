package code;

public interface Codage {
	public String code(String s);
}
