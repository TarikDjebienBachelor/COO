package code;

import java.util.HashMap;
import java.util.Map;

// EX 2 Q1 

public class CodeSimple implements Codage {

	
	private Map<Character,Character> tableConv;
	
	public CodeSimple(Map<Character,Character> tableConv) {
		this.tableConv = tableConv;
	}

	@Override
	public String code(String s) {
		String result = "";
		for(int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (this.tableConv.containsKey(c)) {
				result = result + this.tableConv.get(c);
			}
			else { // inchange
				result = result + c;
			}
		}
		return result;
	}

		// EX 2 Q 2
	public CodeSimple codeInverse() {
		Map<Character,Character> tableInverse = new HashMap<Character, Character>();
		for(Map.Entry<Character,Character> couple : this.tableConv.entrySet()) {
			tableInverse.put(couple.getValue(), couple.getKey());
		}
		return new CodeSimple(tableInverse);
	}
}
