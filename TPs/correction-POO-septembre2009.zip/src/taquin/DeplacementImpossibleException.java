package taquin;

public class DeplacementImpossibleException extends Exception {

}
