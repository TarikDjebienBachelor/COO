package taquin;

// Q6

public enum DirectionDeplacement {
	haut, bas, gauche, droite;
}
