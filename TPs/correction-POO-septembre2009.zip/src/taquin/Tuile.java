package taquin;

// Q1

public class Tuile {
	private int numero;
	
	public static final Tuile TROU = new Tuile(-1);
	
	public Tuile(int numero) {
		this.numero = numero;
	}
	
	public int getNumero() {
		return this.numero;
	}
	
	public String toString() {
		return "tuile "+this.numero;
	}
}
