package application;

import javax.swing.* ;

import application.extensions.Extension;
import application.extensions.PluginChecker;
import application.extensions.event.PluginEvent;
import application.extensions.event.PluginListener;

import java.awt.event.* ;
import java.io.* ;

public class Editeur  {

	JFrame frame ;
	JTextArea texte ;
	PluginChecker checker ;
	JMenu outils ;

	/** Construit un nouvel �diteur
   * @param repertoireDesExtensions le r�pertoire des extensions
   */
   public Editeur(String repertoireDesExtensions) {
		frame = new JFrame("Editeur COO") ;
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		texte = new JTextArea(25,80) ;
		JMenuBar menuBar = new JMenuBar();
		JMenu fichier = new JMenu("Fichier") ;
		menuBar.add(fichier);
		outils = new JMenu("Outils") ;
		menuBar.add(outils);
		fichier.add(new Item(new Nouveau())) ;
		fichier.add(new Item(new Ouvrir())) ;
		fichier.addSeparator() ;
		fichier.add(new Item(new Quitter())) ;
		frame.setJMenuBar(menuBar);
		frame.getContentPane().add(new JScrollPane(texte) , java.awt.BorderLayout.CENTER) ;
		frame.pack() ;
		checker = new PluginChecker(1000 , repertoireDesExtensions) ;
		checker.addPluginListener(new OutilsListener()) ;
	}

	/** Pour faire d�marrer cet �diteur 
  */
  public void start() {
		frame.setVisible(true) ;
		checker.start() ;
	}


	/** Le listener qui ajoute ou retire les plugins
  */
  private class OutilsListener implements PluginListener {
		public void pluginAdded(PluginEvent e) {
			outils.add(new Item(e.getExtension())) ;
		}
		public void pluginRemoved(PluginEvent e) {
			for (int i = 0 ; i < outils.getItemCount(); i++) {
				if (outils.getItem(i).getText().equals(e.getExtension().toString())) {
					outils.remove(i) ; return ;					
				}
			}
		}
	}

	/** Les JMenuItem sp�cifiques � cette application
  */
  private class Item extends JMenuItem implements ActionListener {

		private Extension filtre ;

		Item(Extension filtre) {
			super(filtre.toString()) ;
			this.filtre = filtre ;
			this.addActionListener(this) ; 
		}

		public void actionPerformed(ActionEvent e) {
			texte.setText(filtre.transformer(texte.getText())) ;
		}
	}

	/** Tant qu'� faire autant r�utiliser � fond la notion de plugin
  */
  class Nouveau implements Extension {
		public String transformer(String s) {return "" ;}
		public String toString() {return "Nouveau" ;}
	}

	/** Bon, c'est peut ^etre un peu tordu, mais bon...
  */
  class Ouvrir implements Extension {
		public String transformer(String s) {
			StringBuffer r = new StringBuffer("") ;
			JFileChooser inDialog = new JFileChooser() ;
			if (inDialog.showOpenDialog(frame) == JFileChooser.APPROVE_OPTION) {
				try {
					BufferedReader in = new BufferedReader(new FileReader(inDialog.getSelectedFile())) ;
					texte.setText("") ; String ligne ;
					while((ligne = in.readLine()) != null) {
						r.append(ligne + "\n") ;
					}             
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(frame, "Erreur de lecture pour " +
							inDialog.getSelectedFile().getName()) ;
					return s ;     
				}
				return r.toString() ;
			} else return s ;
		}
		public String toString() {return "Ouvrir" ;}
	}

	class Quitter implements Extension {
		public String transformer(String s) {System.exit(0) ; return texte.getText() ;}
		public String toString() {return "Quitter" ;}
	}

	public static void main(String[] args) {
		String path ;
		if (args.length > 0) path = args[0] ;
		else path = "extensions" ;
		new Editeur(path).start() ;
	}


}

