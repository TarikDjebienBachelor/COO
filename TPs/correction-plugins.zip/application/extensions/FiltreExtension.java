package application.extensions;

import java.io.File;
import java.io.FilenameFilter;

/** Permet de d�tecter si un fichier est un fichier .class d'une extension
 * 
 * @author yroos
 *
 */
public final class FiltreExtension implements FilenameFilter {

	// Un petit singleton
	private static final FiltreExtension SINGLETON = new FiltreExtension() ;

	public static FiltreExtension getInstance() {return SINGLETON ;}

	private FiltreExtension() {}

	public boolean accept(File dir, String name) {
		if (! name.endsWith(".class")) return false ;    
		name = name.substring(0, name.length() - 6) ;
		Class c = null ;
		try {																		
			c = Class.forName(name);
			if (c.isInterface()) return false;
			Class[] allInterfaces = c.getInterfaces() ;
			for (int i = 0; i < allInterfaces.length ; i++) {
				if (allInterfaces[i] == application.extensions.Extension.class) return true ;
			}
			return false ;
		} catch (NoClassDefFoundError e) {
			return false ;
		} catch (ClassNotFoundException e) {
			return false;
		}
	}   
}
