package application.extensions.event ;

import application.extensions.Extension ;

/**
 * @author yroos
 * Un �v�nement correspondant � l'ajout ou � la suppression d'un plugin. 
 */
public class PluginEvent extends java.util.EventObject {

	private static final long serialVersionUID = 20062007L;

	private final Extension extension ;

	/**
	 * @param source le plugin checker � l'origine de l'�v�nement
	 * @param name the name of the new plugin
	 */
	public PluginEvent(Object source, Extension extension) {
		super(source);
		this.extension = extension ;
	}	

	/**
	 * @return l'extension impliqu�e dans l'�v�nement
	 */
	public Extension getExtension() {return extension ;}

}
