package application.extensions.event ;

/**
 * @author yroos
 *  Les listeners d'�v�nements d'ajout ou de suppression de plugin
 */
public interface PluginListener extends java.util.EventListener {

	/**
	 * Quand un plugin est ajout�
	 * @param e l'�v�nement associ� 
	 */
	public void pluginAdded(PluginEvent e) ;

	/**
	 * Quand un plugin est retir�
	 * @param e l'�v�nement associ�
	 */
	public void pluginRemoved(PluginEvent e) ;
}
