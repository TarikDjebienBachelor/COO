package application.extensions;

import java.util.* ;

import java.io.File ;
import java.io.IOException ;

import application.extensions.event.PluginEvent;
import application.extensions.event.PluginListener;


/**
 * @author yroos
 * Le g�n�rateur d'�v�nements
 */
public class PluginChecker {

	private List pluginListeners  ;  
	private int delay ;
	private File directory ;
	private PluginEvent pluginEvent ;

	public PluginChecker(int delay , String directory) {
		this.pluginListeners = new ArrayList() ;
		this.delay = delay ;
		this.directory = new File(directory) ;
		this.pluginEvent = null ;
	}

	public void start() {new javax.swing.Timer(delay , new DirectoryObserver()).start() ;}

	// Pour cr�er une instance de plugin � partie d'un nom de classe
  private boolean createEvent(String extName) {
		String ext = extName.substring(0,extName.length() - 6) ;
		try{
			pluginEvent = new PluginEvent(this , (Extension) (Class.forName(ext).newInstance())) ;
			return true ;
		} catch (Exception ex) {
			System.err.println(ext + "s : plugin not found") ;
			return false ;
		}
	}
			
	/** La partie visible de l'iceberg
  */
  public void addPlugin(String extName) {
		if (createEvent(extName)) firePluginAdded() ;
	}
		
	/** On suit le "guideline" 
  */
  private void firePluginAdded() {
		Iterator listeners = new ArrayList(pluginListeners).iterator() ;
		while (listeners.hasNext()) {
			((PluginListener) listeners.next()).pluginAdded(pluginEvent) ;
		}
	}
	
	public void removePlugin(String extName) {
		if (createEvent(extName)) firePluginRemoved() ;
	}
		
	private void firePluginRemoved() {
		Iterator listeners = new ArrayList(pluginListeners).iterator() ;
		while (listeners.hasNext()) {
			((PluginListener) listeners.next()).pluginRemoved(pluginEvent) ;
		}
	}
	public void addPluginListener(PluginListener listener) {
		pluginListeners.add(listener);
	}

	public void removePluginListener(PluginListener listener) {
		pluginListeners.remove(listener) ;
	}

	// Pour identifier les plugins nouveaux et les plugins obsol�tes.
  private class DirectoryObserver implements java.awt.event.ActionListener {	    

		// Les plugins actuellement op�rationnels
    private Set oldPlugins ;

		DirectoryObserver() {oldPlugins = new HashSet() ; }

		public void actionPerformed(java.awt.event.ActionEvent e) {
			Set newPlugins = new HashSet(Arrays.asList(directory.list(FiltreExtension.getInstance())) );
      Iterator i = new HashSet(oldPlugins).iterator() ;
      // une copie de oldPlugins pour �viter une ConcurrentModificationException
			while(i.hasNext()) {
				String extName = (String) i.next();
				if (! newPlugins.contains(extName)) { // un plugin n'est plus l�
					removePlugin(extName) ;
					oldPlugins.remove(extName) ;
				}				
			}
			i = newPlugins.iterator() ;
			while(i.hasNext()) {
				String extName = (String) i.next();
				if (! oldPlugins.contains(extName)) { // un nouveau plugin est l�
					addPlugin(extName) ;
					oldPlugins.add(extName) ;
				}				
			}
        }
	}
}
