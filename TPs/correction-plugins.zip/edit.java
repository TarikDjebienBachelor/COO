import application.Editeur ;

public class edit  {

	public static void main(String[] args) {
		String path ;
		if (args.length > 0) path = args[0] ;
		else path = "extensions" ;
		new Editeur(path).start() ;
	}
}

