/*
 * Created on 18 mars 2005
 *
 */
package telephonie;

import telephonie.util.Date;

/**
 * @author <a href="mailto:routier@lifl.fr">routier </a>
 * 
 * TODO
 */
public interface Operateur {

   public Connexion seConnecter(Date debut, ModeDePaiement m) throws OperateurSatureException, ModeDePaiementInvalideException;

   public void seDeconnecter(Connexion c, Date fin) throws PasDeConnexionException;

   public float getDureeComptabilisee(Connexion c);

   public int getTarifUnitaire(Connexion c);
}
