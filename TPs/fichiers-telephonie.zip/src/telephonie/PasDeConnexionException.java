/*
 * Created on 18 mars 2005
 *
 */
package telephonie;

/**
 * @author <a href="mailto:routier@lifl.fr">routier</a>
 *
 * TODO
 */
public class PasDeConnexionException extends Exception {

}
