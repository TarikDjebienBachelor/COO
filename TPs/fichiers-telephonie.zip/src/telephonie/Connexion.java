/*
 * Created on 18 mars 2005
 *
 */
package telephonie;

import telephonie.util.Date;

/**
 * @author <a href="mailto:routier@lifl.fr">routier</a>
 *
 * TODO
 */
public class Connexion {

 
   public Connexion(Operateur op, Date debut, ModeDePaiement m) { 
   }
   
   public int heureDebutConnexion() { 
   }

   public Date dateDebutConnexion() { 
   }

   public Date dateFinConnexion() { 
   }

   /**
    * en minutes, arrondi au sup
    * @return
    */
   public int dureeConnexion() { 
   }             
   
   public void finConnexion(Date dateFin) {
   }
   
   public ModeDePaiement mode() { 
   }	
   
   public Operateur getOperateur() {
   }

}
