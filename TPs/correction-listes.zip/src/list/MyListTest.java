package list;

import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.NoSuchElementException;

import junit.framework.TestCase;

public class MyListTest extends TestCase {


	public final void testMyList() {
		MyList<String> myList = new MyList<String>();
		assertTrue(myList!= null);
	}

	public final void testAddFirst() {
		this.testGetFirst();
	}

	public final void testRemoveFirst() {
		MyList<String> myList = new MyList<String>();
		
		boolean t0;
		try {
			myList.removeFirst();
			t0 = false;
		} catch (IllegalStateException e) {
			t0 = true;
		}
		assertTrue(t0);
		
		myList.addFirst("abc");
		myList.removeFirst();
		assertTrue(myList.isEmpty());
		
		MyList<String> myList2 = new MyList<String>();		
		myList2.addFirst("abc");
		myList2.addFirst("cde");
		myList2.removeFirst();
		assertTrue(myList2.getFirst().equals("abc") && myList2.getSize()==1);

	}

	public final void testGetFirst() {
		MyList<String> myList = new MyList<String>();

		boolean t0;
		try {
			myList.getFirst();
			t0 = false;
		} catch (IllegalStateException e) {
			t0 = true;
		}
		assertTrue(t0);
		
		myList.addFirst("abc");
		String first = myList.getFirst();
		assertTrue(first.equals("abc"));
		myList.addFirst("cde");
		first = myList.getFirst();
		assertTrue(first.equals("cde")); 
	}

// 	public final void testTail() {
// 		MyList<String> myList = new MyList<String>();

// 		boolean t0;
// 		try {
// 			myList.tail();
// 			t0 = false;
// 		} catch (IllegalStateException e) {
// 			t0 = true;
// 		}
// 		assertTrue(t0);
		
// 		myList.addFirst("abc");
// 		MyList<String> tail = myList.tail();
// 		assertTrue(tail.isEmpty());
// 		myList.addFirst("cde");
// 		tail = myList.tail();
// 		String first = tail.getFirst();
// 		assertTrue(first.equals("abc")); 
// 	}
	
	public final void testIsEmpty() {
		MyList<String> myList = new MyList<String>();
		myList.addFirst("abc");
		assertTrue(! myList.isEmpty());
		
		MyList<String> myList2 = new MyList<String>();		
		assertTrue(myList2.isEmpty());
		
	}

	public final void testGetSize() {
		MyList<String> myList = new MyList<String>();
		assertTrue(myList.getSize() ==  0);
		myList.addFirst("abc");		
		assertTrue(myList.getSize() ==  1);
		
		myList.addFirst("cde");
		assertTrue(myList.getSize() ==  2);
		
	}

	public final void testContains() {
		MyList<String> myList = new MyList<String>();

		assertTrue(!myList.contains("abc"));
		
		myList.addFirst("abc");
		assertTrue(myList.contains("abc") && !myList.contains(3));
		myList.addFirst("cde");
		assertTrue(myList.contains("abc") && myList.contains("cde") && !myList.contains(3));
		
	}

	public final void testIterator() {
		MyList<String> myList = new MyList<String>();
		Iterator<String> it = myList.iterator();
		
		assertTrue(!it.hasNext());

		boolean t0;
		try {
			it.next();
			t0 = false;
		} catch (NoSuchElementException e) {
			t0 = true;
		}
		assertTrue(t0);

		
		myList.addFirst("abc");
		myList.addFirst("cde");
		it = myList.iterator();
		assertTrue(it.hasNext());
		assertTrue(it.next().equals("cde"));
		assertTrue(it.hasNext());
		assertTrue(it.next().equals("abc"));
		assertTrue(!it.hasNext());
		
		it = myList.iterator();
		try {
			it.remove();
			t0 = false;
		} catch (IllegalStateException e) {
			t0 = true;
		}
		assertTrue(t0);


		
		it.next();
		it.remove();

		assertTrue(myList.getSize() == 1);
	
		assertTrue(myList.getFirst().equals("abc"));	
		try {
			it.remove();
			t0 = false;
		} catch (IllegalStateException e) {
			t0 = true;
		}

		assertTrue(t0);

		assertTrue(it.next().equals("abc"));
		it.remove();
		assertTrue(myList.isEmpty());

		myList.addFirst("abc");
		myList.addFirst("cde");
		it = myList.iterator();
		it.next();
		it.next();
		it.remove();
		assertTrue(myList.getSize() == 1);
		assertTrue(myList.getFirst().equals("cde"));
	}

	public final void testIterable() {
		MyList<String> myList = new MyList<String>();
		myList.addFirst("abc");
		myList.addFirst("cde");
		myList.addFirst("fgh");
		myList.addFirst("ijk");
		// syntaxe autoris�e sur les it�rables 
		for(String s : myList) { 
			System.out.println(s);
		}
	}
	
	public final void testConcurrentModification() {
		MyList<String> myList = new MyList<String>();
		Iterator<String> it = myList.iterator();		
		myList.addFirst("abc");
		myList.addFirst("cde");
		it = myList.iterator();
		boolean t0;
		try {
			it.next();
			t0 = true;
		} catch(ConcurrentModificationException e) {
			t0 = false;
		}
		assertTrue(t0);
		// rupture du contrat de it :
		myList.addFirst("rupture");
		try {
			it.next();
			t0 = false;
		} catch(ConcurrentModificationException e) {
			t0 = true;
		}
		assertTrue(t0);
	}
}
