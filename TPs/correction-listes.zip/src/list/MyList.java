package list;

import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class MyList<E> implements Iterable<E> {

	private Node head;
	// pour gerer les modifications concurrentes
	private int nbModif;
	
	public MyList() {	
		this.head = null;
		this.nbModif =0;
	}
	
	public void addFirst(E e) {
		Node first = new Node(e, head);
		this.head = first;
		this.nbModif++;
	}
	
	public void removeFirst() throws IllegalStateException {
		if (this.isEmpty()) {
			throw new IllegalStateException("the list is empty");
		}
		this.head = this.head.next;
		this.nbModif++;
	}
	
	public E getFirst() throws IllegalStateException {
		if (this.isEmpty()) {
			throw new IllegalStateException("the list is empty");
		}
		return this.head.value;
	}
	
// 	public MyList<E> tail() throws IllegalStateException {
// 		if (this.isEmpty()) {
// 			throw new IllegalStateException("the list is empty");
// 		}
// 		MyList<E> result = new MyList<E>();
// 		result.head = head.next;
// 		return result;
// 	}
	
	public boolean isEmpty() {
		return this.head == null;
	}
	
	public int getSize() {
		Node node  = this.head;
		int result = 0;
		while (node != null) {
			result = result + 1;
			node = node.next;
		}
		return result;
	}
	
	public boolean contains(Object o) {
		Node node  = this.head;
		while (node != null) {
			if (node.value.equals(o)) {
				return true;
			}
			node = node.next;
		}
		return false;
	}
	
	public Iterator<E> iterator() {		
		return new MyIterator();
	}
	
	// *********************************
	private class Node {
		private E value;
		private Node next;
		
		public Node(E value, Node next) {
			this.value = value;
			this.next = next;
		}
		
		public Node(E value) {
			this.value = value;	
			this.next = null;
		}
	}

	// **********************************
	private class MyIterator implements Iterator<E> {

		private Node current;
		private Node previous;
		// pour les modifications concurrentes
		private int nbModifConnues;
		
		public MyIterator() {
			this.current = null;
			this.previous = null;
			this.nbModifConnues = MyList.this.nbModif;
		}
		
		@Override
		public boolean hasNext() {
			if (this.current == null) {
				// cas premier appel
				return MyList.this.head != null;
			} 
			else {
				return this.current.next != null;
			}
			
		}

		@Override
		public E next() throws NoSuchElementException, ConcurrentModificationException {
			
			if (this.nbModifConnues !=	MyList.this.nbModif) {
				throw new ConcurrentModificationException();
			}
			
			if (! this.hasNext()) {
				throw new NoSuchElementException();
			}
			
			this.previous = this.current; 
			if (this.current == null) {		
				// cas premier appel
				this.current = MyList.this.head;
			} 
			else {
				this.current = this.current.next;
			}		
			return this.current.value;
		}

		@Override
		public void remove() throws IllegalStateException, ConcurrentModificationException {
			
			if (this.nbModifConnues !=	MyList.this.nbModif) {
				throw new ConcurrentModificationException();
			}
			
			if (this.current == null) {		
				// next non encore appele
				throw new IllegalStateException();
			}
			if (this.current == this.previous) {
				// next pas rappele depuis dernier remove
				throw new IllegalStateException();
			}
			

			if (this.current == MyList.this.head) {
				// suppression du premier element
				MyList.this.removeFirst(); 				 // genere le MyList.this.nbModif++;
				this.nbModifConnues++;
			} else {
				this.previous.next = this.current.next;
				this.nbModifConnues++;
				MyList.this.nbModif++;
			}
								
			this.current = this.previous;
		}
		
	}

	
	
}
