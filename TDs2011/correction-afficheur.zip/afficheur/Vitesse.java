/*
 * Created on 11 mars 2005
 *
 */
package afficheur;

/**
 * @author <a href="mailto:routier@lifl.fr">routier </a>
 */

public class Vitesse extends Latence {

   private int vitesse;

   /**
    * @param tailleAffichage
    */
   public Vitesse(int tailleAffichage, int latence, int vitesse) {
      super(tailleAffichage, latence);
      this.vitesse = vitesse;
   }

   /**
    * @see afficheur.Afficheur#decale()
    */
   public void decale() {
      for(int i =0; i<this.vitesse; i++ ) {
         super.decale();
      }
   }
}