/*
 * Created on 11 mars 2005
 *
 */
package afficheur;

import java.util.Iterator;

/**
 * @author <a href="mailto:jean-christophe.routier@lifl.fr">routier</a>
 * 
 */

public class FileFIFOArray<E> {

	private E[] suite;

	public FileFIFOArray(int largeur) {
		// on ne peut pas faire new E[]..., pb "generic array creation"
		this.suite = (E[]) new Object[largeur];
	}

	public FileFIFOArray(int largeur, E v) {
		this(largeur);
		this.raz(v);
	}

	public String toString() {
		StringBuffer result = new StringBuffer("");
		for (E e : suite) {
			result = result.append(e.toString());
		}
		return result.toString();
	}

	public void raz(E v) {
		for (int i = 0; i < this.suite.length; i++) {
			this.suite[i] = v;
		}
		// /!\ ET NON :
		// for (E e : this.suite) {
		// e = v;
		// }
	}

	public E ajoute(E in) {
		E out = this.suite[0];
		for (int i = 0; i < this.suite.length - 1; i++) {
			this.suite[i] = this.suite[i + 1];
		}
		this.suite[this.suite.length - 1] = in;
		return out;
	}

	// public static void main(String[] args) {
	// FileFIFO<Character> fifo1 = new FileFIFO<Character>(5,' ');
	// System.out.println(fifo1);

	// FileFIFO<String> fifo2 = new FileFIFO<String>(5,"a");
	// System.out.println(fifo2.ajoute("b"));
	// System.out.println(fifo2);
	// }

}
