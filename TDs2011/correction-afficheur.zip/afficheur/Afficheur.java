/*
 * Created on 11 mars 2005
 *
 */
package afficheur;

/**
 * @author <a href="mailto:routier@lifl.fr">routier</a>
 
 */

public class Afficheur {

   protected char[] message;
   protected FileFIFO<Character> decaleur;
   protected int indexCourant;  // pour retenir � quel caract�re du message on est arriv�

   /**
    * 
    */
   public Afficheur(int tailleAffichage) {
      this.decaleur = new FileFIFO<Character>(tailleAffichage,' ');
   }

   public void setMessage(char[] message) {      
      this.message = message;
      this.indexCourant = 0;
   }

   public void decale() {
      this.decaleur.ajoute(this.message[this.indexCourant]);
      this.indexCourant = (this.indexCourant + 1) % this.message.length;
   }

   public String toString() {
      return this.decaleur.toString();
   }

}
