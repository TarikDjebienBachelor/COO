/*
 * Created on 11 mars 2005
 *
 */
package afficheur;

/**
 * @author <a href="mailto:routier@lifl.fr">routier</a>
 */

public class Latence extends Afficheur {

   private int latence;
   
   /**
    * @param tailleAffichage
    */
   public Latence(int tailleAffichage, int latence) {
      super(tailleAffichage);
      this.latence = latence;
   }

   
   /**
    * Obtenir la latence revient � ajouter <t>latence</t> espaces en
    * fin de message (on aurait pu g�rer cela au niveau de top() )
    * @see afficheur.Afficheur#setMessage(char[])
    */
   public void setMessage(char[] msg) {
      char[] messageAvecLatence = new char[msg.length + this.latence];
      int i = 0;
      for( ; i < msg.length; i++) {
         messageAvecLatence[i] = msg[i];
      }
      for( ; i < messageAvecLatence.length; i++ ) {
         messageAvecLatence[i] = ' ';
      }
      super.setMessage(messageAvecLatence);
   }
   
}
