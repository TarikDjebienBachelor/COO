/*
 * Created on 11 mars 2005
 *
 */
package afficheur;

import java.util.ArrayList;

/**
 * @author <a href="mailto:jean-christophe.routier@lifl.fr">routier</a>
 * On g�re la FIFO avec une liste circulaire 
 */
public class FileFIFO<E> {

   private ArrayList<E> suite;
   private int tete;
   private int largeur; // on pourrait utiliser this.suite.size()
   
   public FileFIFO(int largeur) {   		
       this.suite = new ArrayList<E>();
       this.tete = 0;
       this.largeur = largeur;
       // on remplit la file de "vide"
       for (int i = 0; i< this.largeur; i++) {
      	 this.suite.add(null);
       }
   }

   public FileFIFO(int largeur, E v) {
       this(largeur);
       this.raz(v);
   }

   public String toString() {
       StringBuffer result = new StringBuffer("");
       for (int i = this.tete; i< this.tete+this.largeur; i++) {
      	 E e = this.suite.get(i%this.largeur);
      	 result = result.append(e.toString());	
      }
      return result.toString();
   }


   public void raz(E v) {
       for (int i = 0; i< this.largeur; i++) {
      	 this.suite.set(i, v);
       }
   }

   public E ajoute(E in) {
      E out = this.suite.get(this.tete);
      this.suite.set(this.tete, in);
      this.tete = (this.tete+1) % this.largeur;
      return out;
   }

//     public static void main(String[] args) {
// 	FileFIFO<Character> fifo1 = new FileFIFO<Character>(5,' ');
// 	System.out.println(fifo1);

// 	FileFIFO<String> fifo2 = new FileFIFO<String>(5,"a");
// 	System.out.println(fifo2.ajoute("b"));
// 	System.out.println(fifo2);
//     }

}
