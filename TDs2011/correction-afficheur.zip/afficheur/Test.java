/*
 * Created on 11 mars 2005
 *
 */
package afficheur;

/**
 * @author <a href="mailto:routier@lifl.fr">routier </a>
 * 
 * TODO
 */

public class Test {

   public void tester(Afficheur afficheur) {
      char[] message = { 'a', 'b', 'c', 'd' };
      afficheur.setMessage(message);
      for (int i = 0; i < 13; i++) {
         afficheur.decale();
         System.out.println("<<" + afficheur + ">>");
      }
   }

   public static void main(String[] args) {
      Test t = new Test();
      t.tester(new Afficheur(5));
      System.out.println("*********************************");
      t.tester(new Latence(5,3));
      System.out.println("*********************************");
      t.tester(new Vitesse(5,3,2));

   }
}
