package transport;

public class Routier extends EncombrementPoids {

   public Routier(int distance) {
      super(distance, 38000);
   }


   public int cout() {
      return 4 * this.distance * this.encombrementCourant;
   }

}
