/*
 * Created on 24 f�vr. 2005
 *
 */
package transport;

/**
 * @author <a href="ailto:routier@lifl.fr"routier</a>
 * 
 * TODO
 */

public abstract class EncombrementVolume extends Cargaison {

   /**
    * @param d
    * @param l
    */
   public EncombrementVolume(int d, int l) {
      super(d, l);
    }

   protected int critereEncombrement(Marchandise m) {
      return m.volume();
   }

}
