package transport;

public class EncombrementLimiteAtteintException extends Exception {

   public EncombrementLimiteAtteintException() {
      super();
   }

}