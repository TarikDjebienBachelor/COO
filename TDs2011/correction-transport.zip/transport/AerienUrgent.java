package transport;

public class AerienUrgent extends Aerien {

   public AerienUrgent(int distance) {
      super(distance);
   }

   public int cout() {
      return 2 * super.cout();
   }

}