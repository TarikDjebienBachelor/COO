package transport;

public class Marchandise {
   private int poids;
   private int volume;

   public Marchandise(int poids, int volume) {
      this.poids = poids;
      this.volume = volume;
   }

   public int poids() { // retourne le poids en kg
      return poids;
   }

   public int volume() { // retourne le volume en dm3
      return volume;
   }


   private Cargaison cargaison;

   public Cargaison getCargaison() {
      return cargaison;
   }
   public void setCargaison(Cargaison cargaison) {
      this.cargaison = cargaison;
   }

}
