package transport;

public class Fluvial extends EncombrementPoids {

   public Fluvial(int distance) {
      super(distance, 300000);
   }

   protected int critereEncombrement(Marchandise m) {
      return m.poids();
   }

   public int cout() {
      return this.distance * this.encombrementCourant;
   }

}
