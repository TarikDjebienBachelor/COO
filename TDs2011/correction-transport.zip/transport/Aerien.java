package transport;

public class Aerien extends EncombrementVolume {

   public Aerien(int distance) {
      super(distance, 80000);
   }


   public int cout() {
      return 10 * this.distance * this.encombrementCourant;
   }

}
