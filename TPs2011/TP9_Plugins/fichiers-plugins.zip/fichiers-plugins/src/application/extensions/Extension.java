package application.extensions;

public interface Extension {

	public String transformer(String s) ;

	public String toString() ;

}
