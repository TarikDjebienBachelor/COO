/*
 * Created on 29 avr. 2005
 *
 */
package kermesse;

/**
 * @author <a href="mailto:routier@lifl.fr">routier</a>
 * 
 * TODO
 */

public interface PolitiqueDeParticipation {

   boolean peutParticiper(Personne p);

}
