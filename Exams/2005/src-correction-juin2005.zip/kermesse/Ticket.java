/*
 * Created on 29 avr. 2005
 *
 */
package kermesse;

/**
 * @author <a href="mailto:routier@lifl.fr">routier</a>
 * 
 * TODO
 */

public class Ticket {

   /**
    * 
    */
   public Ticket(float valeur) {
      this.valeur = valeur;
   }

   /**
    *  
    */
   private float valeur;

   /**
    *  
    */
   public float getValeur() {
      return valeur;
   }


}
