package phrase.mot;

import phrase.Mot;

public class Adjectif extends Mot {

	public Adjectif(String mot) {
		super(mot);	
	}

	public Adjectif(Mot mot) {
		super(mot.toString());	
	}
	
}
