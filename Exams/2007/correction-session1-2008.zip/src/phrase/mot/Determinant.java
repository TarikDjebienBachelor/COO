package phrase.mot;

import phrase.Mot;

public class Determinant extends Mot {

	public Determinant(String mot) {
		super(mot);	
	}

	public Determinant(Mot mot) {
		super(mot.toString());	
	}
}
