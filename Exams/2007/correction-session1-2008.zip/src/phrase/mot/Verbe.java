package phrase.mot;

import phrase.Mot;

public class Verbe extends Mot {

	public Verbe(String mot) {
		super(mot);	
	}
	public Verbe(Mot mot) {
		super(mot.toString());	
	}
}
