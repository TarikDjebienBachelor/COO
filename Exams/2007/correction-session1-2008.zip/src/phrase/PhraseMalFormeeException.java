package phrase;

public class PhraseMalFormeeException extends Exception {
	public PhraseMalFormeeException() {
		super("phrase mal formee");
	}
}
