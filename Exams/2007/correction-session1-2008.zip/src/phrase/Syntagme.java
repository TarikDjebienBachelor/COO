package phrase;

public interface Syntagme {
	public void affiche();
}
