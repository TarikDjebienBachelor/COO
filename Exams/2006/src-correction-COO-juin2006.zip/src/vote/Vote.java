/*
 * Created on 16 juin 2006
 *
 */
package vote;

/**
 * @author <a href="mailto:routier@lifl.fr">routier</a>
 *
 * TODO
 */
public interface Vote {
   public String toString();
   public int hashCode();
   public boolean equals(Object o);
}
