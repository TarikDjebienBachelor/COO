package mediatheque;

import junit.framework.TestCase;

public class MediathequeTest extends TestCase {

	public void testMediatheque() {
		fail("Not yet implemented");
	}

	public void testGetLesDocuments() {
		fail("Not yet implemented");
	}

	public void testAffiche() {
		fail("Not yet implemented");
	}

	public void testAjouteDocument() {
		fail("Not yet implemented");
	}

	public void testSupprimeDocument() {
		fail("Not yet implemented");
	}

	public void testGetDocument() {
		fail("Not yet implemented");
	}

	public void testEmprunte() {
		fail("Not yet implemented");
	}

	public void testRetour() {
		fail("Not yet implemented");
	}

	public void testMain() {
		fail("Not yet implemented");
	}

}
