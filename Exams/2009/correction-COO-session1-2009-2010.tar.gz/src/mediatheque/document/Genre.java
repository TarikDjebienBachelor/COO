package mediatheque.document;

public enum Genre {
	ROCK, CLASSIQUE, JAZZ, POP;
}
