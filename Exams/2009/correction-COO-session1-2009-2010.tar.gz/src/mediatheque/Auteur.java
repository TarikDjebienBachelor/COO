package mediatheque;

public interface Auteur {
	
	public String toString();
}
