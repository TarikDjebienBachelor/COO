package mediatheque;

import mediatheque.document.Document;

public class Reference {

	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return super.equals(obj);
	}

	public int hashCode() {
		// TODO Auto-generated method stub
		return super.hashCode();
	}

	public static Reference genereReference(Document doc) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
}
