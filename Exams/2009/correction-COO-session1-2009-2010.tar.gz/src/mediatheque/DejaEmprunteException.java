package mediatheque;

@SuppressWarnings("serial")
public class DejaEmprunteException extends Exception {

}
