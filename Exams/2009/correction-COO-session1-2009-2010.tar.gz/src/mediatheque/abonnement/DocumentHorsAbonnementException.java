package mediatheque.abonnement;

import mediatheque.document.Document;

@SuppressWarnings("serial")
public class DocumentHorsAbonnementException extends Exception {

	public DocumentHorsAbonnementException(Document doc) {
		// TODO Auto-generated constructor stub
	}
	
}
