package jeu;

public interface Action {
    /**
     * indique si l’action est possible ou non en fonction de la situation
     * courante du jeu
     * 
     * @return true si et seulement si l’action est possible a cet instant
     */
    public boolean estPossible();

    /**
     * fournit une chaine de caracteres representant le nom pour cette action
     * 
     * @return le nom de cette action
     */
    public String toString();

    /**
     * le personnage passe en parametre execute cette action
     * 
     * @param p le personnage qui execute l’action
     */
    public void execute(Personnage p);
}
