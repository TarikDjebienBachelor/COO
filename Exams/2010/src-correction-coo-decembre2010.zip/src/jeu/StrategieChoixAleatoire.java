package jeu;

import java.util.List;
import java.util.Random;

public class StrategieChoixAleatoire implements StrategieChoixAction {
    private static final Random RANDOM = new Random();

   
    public Action choisitAction(List<Action> actionsPossibles) {
        int alea = RANDOM.nextInt(actionsPossibles.size()); 
        return actionsPossibles.get(alea);
    } 
    
}
