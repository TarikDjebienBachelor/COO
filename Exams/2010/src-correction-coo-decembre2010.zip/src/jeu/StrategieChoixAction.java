package jeu;

import java.util.List;

public interface StrategieChoixAction {

    public Action choisitAction(List<Action> actionsPossibles);

}
