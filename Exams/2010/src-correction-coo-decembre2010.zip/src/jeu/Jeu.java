package jeu;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Jeu {
    private List<Personnage> lesPerso;

    private static final Jeu INSTANCE = new Jeu();

    private Jeu() {
        this.lesPerso = new ArrayList<Personnage>();
    }

    public Jeu getInstance() {
        return Jeu.INSTANCE;
    }

    public boolean estFini() {
        return false;
    }

    public void joue() {
        while (!this.estFini()) {
            Iterator<Personnage> it_perso = this.lesPerso.iterator();
            while (it_perso.hasNext()) {
                Personnage perso = it_perso.next();
                // le personnage agit : il choisit une action puis l’execute
                perso.agit();
                // si le personnage est mort on le retire du jeu
                if (perso.getEnergie() < 0) {
                    it_perso.remove();
                }
            }
        }
    }
}
