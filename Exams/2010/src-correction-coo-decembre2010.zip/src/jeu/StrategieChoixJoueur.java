package jeu;

import java.util.List;
import generics.ListChoser;

/**
 * Pourrait être un Singleton
 *
 */
public class StrategieChoixJoueur implements StrategieChoixAction {

    private static final ListChoser CHOSER = new ListChoser(); 
   
    public Action choisitAction(List<Action> actionsPossibles) {
        Action choisie = CHOSER.chose("choisissez une action : ",actionsPossibles);
        return choisie;
    }

}
