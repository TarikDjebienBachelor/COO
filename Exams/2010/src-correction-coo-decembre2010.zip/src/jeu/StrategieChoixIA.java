package jeu;

import java.util.List;

public class StrategieChoixIA implements StrategieChoixAction {

    @Override
    public Action choisitAction(List<Action> actionsPossibles) {
        Action actionChoisieParLIA = null;
        // code pour gérer le choix de l'action
        return actionChoisieParLIA;
    }

}
