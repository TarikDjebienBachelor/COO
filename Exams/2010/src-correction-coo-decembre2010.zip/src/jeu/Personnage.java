package jeu;

import java.util.ArrayList;
import java.util.List;

/**
 * Permet de représenter l'ensemble des personnages : qu'ils soient "joueurs" ou "non joueurs". 
 * Ceux-ci sont différencier par leur attribut "stratégie" qui détermine comment sont choisies les actions à exécuter.
 * Le design pattern Strategy est mis en oeuvre.
 */
public class Personnage {

    private int energie;
    private List<Action> lesActions;
    private String name;
    private StrategieChoixAction strategie;
    
    public Personnage(String name, int energie, StrategieChoixAction strategie) {
        this.name = name;
        this.energie = energie;
        this.lesActions = new ArrayList<Action>();
        this.strategie = strategie;
    }
        
    public void addAction(Action a) {
        this.lesActions.add(a);
    }
    public void removeAction(Action a) {
        this.lesActions.remove(a);
    }
    
    public void agit() {
        List<Action> actionsPossibles = new ArrayList<Action>();
        for(Action a : this.lesActions) {
            if (a.estPossible()) {
                actionsPossibles.add(a);
            }
        }
        Action actionChoisie = this.strategie.choisitAction(actionsPossibles);
        actionChoisie.execute(this);
    }

    public int getEnergie() {
        return this.energie;
    }

    public String getName() {
        return name;
    }

}
