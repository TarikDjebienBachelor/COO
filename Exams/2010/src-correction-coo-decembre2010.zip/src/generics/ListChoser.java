package generics;

import java.util.List;

public class ListChoser {
    public <T> T chose(String msg, List<T> list) {
        if (list.isEmpty()) {
            return null;
        }
        System.out.println(msg);
        System.out.println("        0 - none");
        int index = 1;
        for (Object item : list) {
            System.out.println("        " + (index++) + " - " + item);
        }
        System.out.println("        choice ?");
        int choice = scanner.TestScanner.saisieEntier(list.size() + 1);
        if (choice == 0) {
            return null;
        } else {
            return list.get(choice - 1);
        }
    }
}
