package musique;

public abstract class Bois implements Instrument {


}
