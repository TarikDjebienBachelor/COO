package musique;

public class Trompette extends Cuivre implements InstrumentPhilharmonique {

    public void accorder() {
      
    }


    public void jouer() {
     
    }

}
