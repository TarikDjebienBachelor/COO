package musique;

public class Hautbois extends Bois implements InstrumentPhilharmonique {

    public void accorder() {
      
    }


    public void jouer() {
     
    }

}
