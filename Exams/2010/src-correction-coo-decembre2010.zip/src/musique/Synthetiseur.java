package musique;

public class Synthetiseur extends Clavier implements Electrique {

    public Synthetiseur(int nbTouches) {
        super(nbTouches);
    }

    public void accorder() {
      
    }


    public void jouer() {
     
    }

}
