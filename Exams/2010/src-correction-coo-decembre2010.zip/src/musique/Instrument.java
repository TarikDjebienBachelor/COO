package musique;

public interface Instrument {
    public void jouer();
    public void accorder(); 
}
