package musique;

public abstract class Corde implements Instrument {

    protected int nbCordes;

    public Corde(int nbCordes) {
        this.nbCordes = nbCordes;
    }
}
