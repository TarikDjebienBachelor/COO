package musique;

public class Violon extends Corde implements InstrumentPhilharmonique {

    public Violon(int nbCordes) {
        super(nbCordes);
    }

    public void accorder() {
      
    }


    public void jouer() {
     
    }

}
