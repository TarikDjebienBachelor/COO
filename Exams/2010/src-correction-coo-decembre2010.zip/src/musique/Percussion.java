package musique;

public abstract class Percussion implements Instrument {


}
