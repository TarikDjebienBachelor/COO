package musique;

public interface Electrique {

}
