package musique;

public class Piano extends Clavier {

    public Piano(int nbTouches) {
        super(nbTouches);
    }

    public void accorder() {
      
    }


    public void jouer() {
     
    }

}
