package musique;

public interface InstrumentPhilharmonique {

}
