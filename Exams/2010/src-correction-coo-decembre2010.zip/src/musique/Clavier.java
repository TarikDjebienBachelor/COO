package musique;

public abstract class Clavier implements Instrument {

    protected int nbTouches;

    public Clavier(int nbTouches) {
        this.nbTouches = nbTouches;
    }

}
