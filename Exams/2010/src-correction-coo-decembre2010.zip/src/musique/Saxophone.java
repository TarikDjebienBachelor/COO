package musique;

public class Saxophone extends Bois {

    public void accorder() {
      
    }

    public void jouer() {
     
    }

}
