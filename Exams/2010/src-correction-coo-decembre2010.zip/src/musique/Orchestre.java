package musique;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Orchestre implements Iterable<Instrument> { 
    private List<Instrument> lesInstruments;
    
    public Orchestre() {
        this.lesInstruments = new ArrayList<Instrument>();
    }
    
    public void addInstrument(Instrument instrument) {
        this.addInstrument(instrument);
    }
    
    public List<Instrument> getListeInstruments() {
        return this.lesInstruments;
    }
    
    public Iterator<Instrument> iterator() {
        return this.lesInstruments.iterator();
    }
}
