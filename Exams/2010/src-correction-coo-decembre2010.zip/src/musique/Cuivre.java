package musique;

public abstract class Cuivre implements Instrument {


}
