package musique;

public class GuitareElectrique extends Corde implements Electrique {

    public GuitareElectrique(int nbCordes) {
        super(nbCordes);
    }

    public void accorder() {
      
    }


    public void jouer() {
     
    }

}
