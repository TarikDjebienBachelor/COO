package documents;

/**
 * le siegn pattern Composite est mis en place
 *
 */
public abstract class TextElement {
    public abstract void affiche();
}
