package documents;

import java.util.Iterator;
import java.util.List;

/**
 * élément Composite du design pattern Composite
 *
 * @param <T> le type des éléments qui composent le composite 
 */
public class CompositeTextElement<T extends TextElement> extends TextElement implements Iterable<T> {

    protected String titre;
    protected List<T> lesElements;

    public CompositeTextElement(String titre, List<T> lesElements) {
        this.titre = titre;
        this.lesElements = lesElements;
    }

    public void affiche() {
        System.out.println(this.titre);
        for (T t : this.lesElements) {
            t.affiche();
        }
    }

    public Iterator<T> iterator() {
        return this.lesElements.iterator();
    }

}
