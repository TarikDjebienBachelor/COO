package documents;

import java.util.List;

/**
*
* joue à la fois le rôle d'élément feuille du design pattern Composite (pour Section) 
* et de composite (composé de paragraphes)
* 
*/
public class SousSection extends CompositeTextElement<Paragraph> {

    public SousSection(String titre, List<Paragraph> lesElements) {
        super(titre, lesElements);        
    }

}
