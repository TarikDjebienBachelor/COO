package documents;

/**
 * élément feuille du design pattern Composite
 *
 */
public class Paragraph extends TextElement {
    private String contenu;
    
    public Paragraph(String contenu) {
        this.contenu = contenu;
    }
    
    public String getContenu() {
        return this.contenu;
    }
    
    public void affiche() {

    }

}
