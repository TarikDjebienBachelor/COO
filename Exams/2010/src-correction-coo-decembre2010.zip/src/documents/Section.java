package documents;

import java.util.List;

/**
 *
 * joue à la fois le rôle d'élément feuille du design pattern Composite (pour Document) 
 * et de composite (composé de sous-sections)
 * 
 */
public class Section extends CompositeTextElement<SousSection> {

    public Section(String titre, List<SousSection> lesElements) {
        super(titre, lesElements);        
    }

}
