package documents;

import java.util.List;

/**
 * élément Composite du design pattern
 *
 */
public class Document extends CompositeTextElement<Section> {

    protected String auteur;
    protected Paragraph resume;
    
    public Document(String titre, String auteur, Paragraph resume, List<Section> lesElements) {
        super(titre, lesElements);    
        this.auteur = auteur;
        this.resume = resume;
    }

    
    public String getAuteur() {
        return this.auteur;
    }


    public Paragraph getResume() {
        return this.resume;
    }


    public void affiche() {
        System.out.println(this.titre);        
        System.out.println(this.auteur);
        this.resume.affiche();
        for (Section s : this.lesElements) {
            s.affiche();
        }
    }

    
}
