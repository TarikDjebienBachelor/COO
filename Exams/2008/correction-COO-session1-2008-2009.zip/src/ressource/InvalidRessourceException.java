package ressource;

public class InvalidRessourceException extends Exception {

	public InvalidRessourceException(String msg) {
		// TODO Auto-generated constructor stub
	}

}
