package action;

public enum ActionState {
	non_commencee, terminee;
}
