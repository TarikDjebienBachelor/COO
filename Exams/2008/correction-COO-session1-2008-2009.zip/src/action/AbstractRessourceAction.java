package action;

import ressource.GestionnaireRessources;
import ressource.Ressource;
import ressource.RessourceUser;

public abstract class AbstractRessourceAction<R extends Ressource> extends Action {

	protected GestionnaireRessources<R> gestionnaire;
	protected RessourceUser<R> user;
	
	public AbstractRessourceAction(String msg, GestionnaireRessources<R> gestionnaire, RessourceUser<R> user) {
		super(msg);
		this.gestionnaire = gestionnaire;
		this.user = user;
	}

	
}
