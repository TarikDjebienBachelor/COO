/*
 * Created on 10 juin 2004
 *
 */
package circuit;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public abstract class ComposantUneEntreeUneSortie extends ComposantASortie {	
	
	protected ComposantASortie entree;

	public ComposantASortie getEntree() {
		return entree;
	}

	public void setEntree(ComposantASortie entree) {
		this.entree = entree;
//	on pourrait automatiquement g�rer :
		 // entree.addSortie(this);
	}

}
