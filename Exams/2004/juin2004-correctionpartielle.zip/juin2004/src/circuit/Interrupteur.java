/*
 * Created on 10 juin 2004
 *
 */
package circuit;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class Interrupteur  extends ComposantUneEntreeUneSortie {

	private boolean ouvert = true;

	/**
	 * @see circuit.Composant#isActive()
	 */
	public boolean isActive() {
		// TODO Auto-generated method stub
		return !ouvert;
	}

	public boolean getOuvert() {
		return ouvert;
	}

	public void setOuvert(boolean ouvert) {
		this.ouvert = ouvert;
	}

}