/*
 * Created on 10 juin 2004
 *
 */
package circuit;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class PorteNonEt extends ComposantDeuxEntreesUneSortie {

	private PorteNon non = new PorteNon();
	private PorteEt et = new PorteEt();
	
	public PorteNonEt() {
		this.non.setEntree(et);
	}
	
	
	/**
	 * @see circuit.Composant#isActive()
	 */
	public boolean isActive() {		
		return non.isActive();
	}

	/**
	 * @see circuit.ComposantDeuxEntreesUneSortie#setEntree1(circuit.Composant)
	 */
	public void setEntree1(ComposantASortie entree1) {		
		super.setEntree1(entree1);
		this.et.setEntree1(entree1);
	}

	/**
	 * @see circuit.ComposantDeuxEntreesUneSortie#setEntree2(circuit.Composant)
	 */
	public void setEntree2(ComposantASortie entree2) {		
		super.setEntree2(entree2);
		this.et.setEntree2(entree2);
	}

}
