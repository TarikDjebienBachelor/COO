/*
 * Created on 10 juin 2004
 *
 */
package circuit;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class PorteEt extends ComposantDeuxEntreesUneSortie {	/**
	 * @see circuit.Composant#isActive()
	 */
	public boolean isActive() {		
		return this.entree1.isActive() && this.entree2.isActive();
	}

}