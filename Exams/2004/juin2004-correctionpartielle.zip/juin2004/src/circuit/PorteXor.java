/*
 * Created on 10 juin 2004
 *
 */
package circuit;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 * a xor b = (non a et b) ou (a et non b) 
 */
public class PorteXor extends ComposantDeuxEntreesUneSortie {

	private PorteEt et1 = new PorteEt();
	private PorteEt et2 = new PorteEt();
	private PorteOu ou = new PorteOu();
	private PorteNon non1 = new PorteNon();
	private PorteNon non2 = new PorteNon();

	public PorteXor() {
		et1.setEntree1(non1);
		et2.setEntree2(non2);
		ou.setEntree1(et1);
		ou.setEntree2(et2);
	}

	/**
	 * @see circuit.ComposantDeuxEntreesUneSortie#setEntree1(circuit.Composant)
	 */
	public void setEntree1(ComposantASortie entree1) {
		super.setEntree1(entree1);
		non1.setEntree(entree1);
		et2.setEntree1(entree1);
	}

	/**
	 * @see circuit.ComposantDeuxEntreesUneSortie#setEntree2(circuit.Composant)
	 */
	public void setEntree2(ComposantASortie entree2) {
		super.setEntree2(entree2);
		non2.setEntree(entree2);
		et1.setEntree2(entree2);
	}

	/**
	 * @see circuit.Composant#isActive()
	 */
	public boolean isActive() {
		return ou.isActive();
	}

}