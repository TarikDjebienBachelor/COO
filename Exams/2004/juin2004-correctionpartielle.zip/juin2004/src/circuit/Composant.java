/*
 * Created on 10 juin 2004
 *
 */
package circuit;

//import javax.swing.JComponent;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public interface Composant {	
	
	public boolean isActive();

	// FACTORY METHOD pour produire un composant graphique par composant
	// (ou on cr�e une interface ComposantGrahique et on retourne ce type.)
	// ceci pour faire simple
	// 
	// on pourrait imaginer une r�ponse analogue � celle du cours dans le cas de la ShapeFactory
	//
	//public JComponent getGraphicalView();

}
