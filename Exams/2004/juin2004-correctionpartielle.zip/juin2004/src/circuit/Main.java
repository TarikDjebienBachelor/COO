/*
 * Created on 10 juin 2004
 *
 */
package circuit;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class Main {

	public static void main(String[] args) {
	
		Generateur g1 = new Generateur();
		
		Interrupteur i1 = new Interrupteur();
		Interrupteur i2 = new Interrupteur();
		
		// on ne g�re pas les connexions des sorties ici
		
		i1.setEntree(g1);
		i2.setEntree(g1);
		
		i1.setOuvert(true);
		i2.setOuvert(true);
		
//		PorteEt et = new PorteEt();				
//				et.setEntree1(i1);
//				et.setEntree2(i2);
//				Ampoule amp = new Ampoule();
//				amp.setEntree(et);
	
	
		PorteXor xor = new PorteXor();				
				xor.setEntree1(i1);
				xor.setEntree2(i2);
				Ampoule amp = new Ampoule();
				amp.setEntree(xor);
	
		System.out.println(amp.isAllumee());
	}
}
