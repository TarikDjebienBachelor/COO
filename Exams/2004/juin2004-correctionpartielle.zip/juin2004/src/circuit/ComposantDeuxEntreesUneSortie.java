/*
 * Created on 10 juin 2004
 *
 */
package circuit;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public abstract class ComposantDeuxEntreesUneSortie extends ComposantASortie {

	protected ComposantASortie entree2;
	protected ComposantASortie entree1;
	
	public  ComposantASortie getEntree1() {
		return entree1;
	}

	public void setEntree1(ComposantASortie entree1) {
		this.entree1 = entree1;
//	on pourrait automatiquement g�rer :
		 // entree1.addSortie(this);
	}

	public  ComposantASortie getEntree2() {
		return entree2;
	}

	public void setEntree2(ComposantASortie entree2) {
		this.entree2 = entree2;
//	on pourrait automatiquement g�rer :
		 // entree2.addSortie(this);
	}

}