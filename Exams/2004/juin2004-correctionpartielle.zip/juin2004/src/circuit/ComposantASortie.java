/*
 * Created on 10 juin 2004
 *
 */
package circuit;

import java.util.*;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public abstract class ComposantASortie implements Composant {

	/** liste des composants connect�s � la sortie
	 *
	 */
	protected List sortie = new ArrayList();


	public Iterator getSortie() {
		return sortie.iterator();
	}

	public void addSortie(Composant comp) {
		this.sortie.add(comp);
	}

	public void removeSortie(Composant comp) {
		this.removeSortie(comp);
	}
}
