/*
 * Created on 10 juin 2004
 *
 */
package document.formatter;

import document.*;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 * pour respectet le sujet, on garde l'affichage � l'�cran, dans une application plus "r�elle"
 * il faudrait envisager que la plupart des m�thodes retourne une cha�ne de caract�res ou un StringBuffer
 * ou passer en param�tre des m�thodes un "flux de sortie"
 */
public abstract class AbstractFormatter {

	protected abstract void formatHeader(Document doc);

	protected void formatContent(Document doc) {
		this.formatTitle(doc);
		this.formatAbstractAndKeywords(doc);
		this.formatSections(doc.getTheParts());
	}

	protected abstract void formatTitle(Document doc);
	protected abstract void formatAbstractAndKeywords(Document doc);
	
	protected void formatSections(TextPartIterator iterator) {
		while (iterator.hasNextPart()) {
			Section section = (Section) iterator.nextPart();
			this.formatTitle(section);
			this.formatSubsections(section.getTheParts());
		}
	}
	protected void formatSubsections(TextPartIterator iterator) {
		while (iterator.hasNextPart()) {
			Subsection subsection = (Subsection) iterator.nextPart();
			this.formatTitle(subsection);
			this.formatParagraphs(subsection.getTheParts());
		}
	}
	protected void formatParagraphs(TextPartIterator iterator) {
		while (iterator.hasNextPart()) {
			Paragraph paragraph = (Paragraph) iterator.nextPart();
			this.formatParagraphContent(paragraph.getContenu());
		}
	}

	protected void formatTitle(Section section) {
		String result = this.produceBloc("h1", section.getTitre());
		System.out.println(result);
	}

	protected void formatTitle(Subsection subsection) {
		String result = this.produceBloc("h2", subsection.getTitre());
		System.out.println(result);
	}

	protected abstract String produceBloc(String tag, String contenu);
		
		
	protected abstract void formatParagraphContent(String contenu);

	protected abstract void formatFooter(Document doc);

	public void formater(Document doc) {
		this.formatHeader(doc);
		this.formatContent(doc);
		this.formatFooter(doc);
	}

}
