/*
 * Created on 10 juin 2004
 *
 */
package document.formatter;

import document.Document;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class LatexFormatter extends AbstractFormatter {

	/**
	 * @see document.formatter.AbstractFormatter#formatHeader(document.Document)
	 */
	protected void formatHeader(Document doc) {
		String result = " \\documentclass[a4paper]{article}\n ";
		result += "\\usepackage[latin1]{inputenc}\n";

		result = this.produceBloc("title", doc.getTitre());
		result += this.produceBloc("author", doc.getAuteur());
		result += this.produceBloc("date", doc.getDateDeCreation());
		result += this.produceBloc("begin", "document");

		System.out.println(result);
	}

	/**
	 * @see document.formatter.AbstractFormatter#formatTitle(document.Document)
	 */
	protected void formatTitle(Document doc) {
		String result = "\\maketitle\n";
		System.out.println(result);
	}

	/**
	 * @see document.formatter.AbstractFormatter#formatAbstractAndKeywords(document.Document)
	 */
	protected void formatAbstractAndKeywords(Document doc) {
		String result = this.produceBloc("begin", "quote");
		result += this.produceBloc("begin", "center");
		result += this.produceBloc("textsl", "R�sum�");
		result += this.produceBloc("end", "center");
		result += doc.getResume().getContenu() + "\n";
		result += this.produceBloc("textsc", "Mots-cl�s~:");
		String[] kw = doc.getMotsCles();
		for (int i = 0; i < kw.length; i++) {
			result = result + kw[i] + ", ";
		}
		System.out.println(result);
	}

	/**
	 * @see document.formatter.AbstractFormatter#formatParagraphContent(java.lang.String)
	 */
	protected void formatParagraphContent(String contenu) {
		System.out.println(contenu + "\n");
	}

	/**
	 * @see document.formatter.AbstractFormatter#formatFooter(document.Document)
	 */
	protected void formatFooter(Document doc) {
		System.out.println("\\end{document}");
	}

	/**
	 * @see document.formatter.AbstractFormatter#produceBloc(java.lang.String, java.lang.String)
	 */
	protected String produceBloc(String tag, String contenu) {
		return "\\" + tag + "{" + contenu + "}";
	}

}
