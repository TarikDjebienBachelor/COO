/*
 * Created on 10 juin 2004
 *
 */
package document.formatter;

import document.Document;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class HtmlFormatter extends AbstractFormatter {

	protected String produceBloc(String tag, String contenu) {
		return "<"+tag+">"+ contenu + "</"+tag+"> \n";
	}

	/**
	 * @see document.formatter.AbstractFormatter#formatHeader(document.Document)
	 */
	protected void formatHeader(Document doc) {
		String result = "<html> \n <header>\n";
		result = result + "<meta http-equiv=<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">\n";
		result = result + "<title>"+doc.getTitre()+"</title> \n";
		result = result + "</header>\n\n";
		result = result + "<body bgcolor=white>";
    System.out.println(result);
	}

	/**
	 * @see document.formatter.AbstractFormatter#formatTitle(document.Document)
	 */
	protected void formatTitle(Document doc) {	
		String result = "<p align=center>\n ";
		result = result + this.produceBloc("h1", doc.getTitre());
		result = result + this.produceBloc("h3", doc.getAuteur());
		result = result + this.produceBloc("h4", doc.getDateDeCreation());
		result = result+"</p> \n";
		System.out.println(result);
	}

	/**
	 * @see document.formatter.AbstractFormatter#formatAbstractAndKeywords(document.Document)
	 */
	protected void formatAbstractAndKeywords(Document doc) {
		String result = "<p align=left>\n";
		result += this.produceBloc("i","R�sum�");
		result += this.produceBloc("br",doc.getResume().getContenu());
		result += this.produceBloc("br", "Mots-cles");
		String[] kw = doc.getMotsCles(); 
		for(int i = 0; i< kw.length; i++) {
				result = result + kw[i]+", ";
		}
		result += result + "</p>\n";
		System.out.println(result);
	}


	/**
	 * @see document.formatter.AbstractFormatter#formatParagraphContent(java.lang.String)
	 */
	protected void formatParagraphContent(String contenu) {
		String result = this.produceBloc("p", contenu);		
		System.out.println(result);	
	}

	/**
	 * @see document.formatter.AbstractFormatter#formatFooter(document.Document)
	 */
	protected void formatFooter(Document doc) {		
		String result = "</body>\n</html>";		
		System.out.println(result);
	}

}
