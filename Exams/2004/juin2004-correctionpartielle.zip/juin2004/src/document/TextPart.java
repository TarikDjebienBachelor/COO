/*
 * Created on 25 mai 2004
 *
 */
package document;


/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public interface TextPart {	}
