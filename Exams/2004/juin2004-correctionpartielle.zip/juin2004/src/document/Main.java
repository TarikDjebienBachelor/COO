/*
 * Created on 10 juin 2004
 *
 */
package document;

import document.formatter.*;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class Main {

	public static void main(String[] args) {

		Section section;
		Subsection subsection;

		Document doc = new Document("un titre", "un auteur", " la date");
		doc.setMotsCles(new String[] { "mot1, mot2" });
		doc.setResume(new Paragraph("bla bla resume"));

		section = new Section("titre section 1");
		subsection = new Subsection("titre subsection 1 1");
		subsection.addParagraph(new Paragraph("contenu par 1 1 1"));
		subsection.addParagraph(new Paragraph("contenu par 1 1 2"));
		section.addSubsection(subsection);
		subsection = new Subsection("titre subsection 1 2");
		subsection.addParagraph(new Paragraph("contenu par 1 2 1"));
		subsection.addParagraph(new Paragraph("contenu par 1 2 2"));
		section.addSubsection(subsection);
		doc.addSection(section);

		section = new Section("titre section 2");
		subsection = new Subsection("titre subsection 2 1");
		subsection.addParagraph(new Paragraph("contenu par 2 1 1"));
		subsection.addParagraph(new Paragraph("contenu par 2 1 2"));
		section.addSubsection(subsection);
		subsection = new Subsection("titre subsection 2 2");
		subsection.addParagraph(new Paragraph("contenu par 2 2 1"));
		subsection.addParagraph(new Paragraph("contenu par 2 2 2"));
		section.addSubsection(subsection);
		doc.addSection(section);
		
		AbstractFormatter formatter;

		System.out.println("***************** HTML *****************");
		formatter = new HtmlFormatter();
		formatter.formater(doc);

		System.out.println("***************** HTML FINI***************** \n\n");

		System.out.println("***************** LATEX *****************");
		formatter = new LatexFormatter();
		formatter.formater(doc);
		System.out.println("***************** LATEX FINI***************** \n\n");
	}
}
