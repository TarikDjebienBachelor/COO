/*
 * Created on 25 mai 2004
 *
 */
package document;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class Paragraph implements TextPart {				
	
	private String contenu;

	public Paragraph(String contenu) {
		this.contenu = contenu;
	}

	public String getContenu() {
		return this.contenu;
	}

}