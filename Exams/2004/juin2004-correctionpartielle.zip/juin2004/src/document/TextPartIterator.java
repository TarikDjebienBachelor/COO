/*
 * Created on 25 mai 2004
 *
 */
package document;

import java.util.*;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class TextPartIterator {

	private Iterator iterator;
	
	public TextPartIterator(Iterator i) {
		this.iterator =i;
	}
	
	public boolean hasNextPart() {		
		return iterator.hasNext();
	}

	
	public TextPart nextPart() throws NoSuchElementException {		
		return (TextPart) iterator.next();
	}

}
