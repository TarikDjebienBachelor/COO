/*
 * Created on 25 mai 2004
 *
 */
package document;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class Section extends CompositeTextPart {

	/**
	 * @param titre
	 */
	public Section(String titre) {
		super(titre);
	}

	public void addSubsection(Subsection subsection) {
		this.theParts.add(subsection);
	}

	/**
	 * @see document.CompositeText#addTextPart(document.TextPart)
	 */
	public void addTextPart(TextPart textPart) {
		this.addSubsection((Subsection) textPart);
	}

}