/*
 * Created on 25 mai 2004
 *
 */
package document;

import java.lang.String;
/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class Document extends CompositeTextPart {		
	
	private String auteur;

	private String dateDeCreation;

	private Paragraph resume;

	private String[] motsCles;

	/**
	 * @param titre
	 */
	public Document(String titre, String auteur, String dateDeCreation) {
		super(titre);		
		this.auteur = auteur;
		this.dateDeCreation = dateDeCreation;
	}

	public String getAuteur() {
		return auteur;
	}

	public String getDateDeCreation() {
		return dateDeCreation;
	}

	public String[] getMotsCles() {
		return motsCles;
	}

	public Paragraph getResume() {
			return resume;
		}
		
	public void setResume(Paragraph resume) {
			this.resume= resume;
		}

	
	/**
	 * @see document.CompositeTextPart#addTextPart(document.TextPart)
	 */
	public void addTextPart(TextPart textPart) {
		this.addSection((Section) textPart);
	}

	public void addSection(Section section)  {
		this.theParts.add(section);
	}
	public void setMotsCles(String[] motsCles) {
		this.motsCles = motsCles;
	}

}