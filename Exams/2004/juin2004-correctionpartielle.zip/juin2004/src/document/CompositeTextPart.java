/*
 * Created on 25 mai 2004
 *
 */
package document;

import java.util.*;
/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public abstract class CompositeTextPart implements TextPart {

	protected String titre;
	
	protected List theParts;

	public CompositeTextPart(String titre) {
		this.titre = titre;
		this.theParts = new ArrayList();
	}
	
	public String getTitre() {
		return titre;
	}

	public abstract void addTextPart(TextPart textPart);

	public TextPartIterator getTheParts() {
		return new TextPartIterator(theParts.iterator());
	}


}