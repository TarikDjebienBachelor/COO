/*
 * Created on 25 mai 2004
 *
 */
package document;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class Subsection extends CompositeTextPart {
	/**
	 * @param titre
	 */
	public Subsection(String titre) {
		super(titre);		
	}

	public void addParagraph(Paragraph paragraph) {
		this.theParts.add(paragraph);
		}

	/**
	 * @see document.CompositeText#addTextPart(document.TextPart)
	 */
	public void addTextPart(TextPart textPart) {
		this.addParagraph((Paragraph) textPart);
	}

}